// Definiere eine Funktion, um die Menüleiste mit Dropdown-Menü zu erstellen
function createMenu() {
    var menuBar = document.createElement('div');
    menuBar.className = 'w3-top';
    menuBar.innerHTML = `
        <div class="w3-bar w3-wide w3-padding w3-card" id="myNavbar" style="background: #161616;">
            <!-- Dropdown-Menü -->
            <div class="w3-dropdown-hover">
                <button class="w3-bar-item w3-button"><i class="fa fa-bars"></i>  <i class="fa fa-caret-down"></i></button>
                <div class="w3-dropdown-content w3-bar-block w3-black">
                    <a href="index.html" class="w3-bar-item w3-button">HOME</a>
                    <a href="about.html" class="w3-bar-item w3-button"><i class="fa fa-user"></i> ABOUT</a>
                    <a href="portfolio.html" class="w3-bar-item w3-button"><i class="fa fa-th"></i> PORTFOLIO</a>
                    <a href="contact.html" class="w3-bar-item w3-button"><i class="fa fa-envelope"></i> CONTACT</a>
                </div>
            </div>
        </div>
    `;

    // Füge die Menüleiste zum Body des Dokuments hinzu
    document.body.prepend(menuBar);
}

// Rufe die Funktion auf, um die Menüleiste zu erstellen und einzufügen, sobald das DOM geladen ist
document.addEventListener('DOMContentLoaded', createMenu);
