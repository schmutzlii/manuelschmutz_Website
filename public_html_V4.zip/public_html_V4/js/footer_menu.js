// Function to fetch Bitcoin price
function fetchBitcoinPrice() {
    const apiUrl = 'https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd';
    return fetch(apiUrl)
        .then(response => response.json())
        .then(data => {
            const bitcoinPrice = data.bitcoin.usd;
            return bitcoinPrice;
        })
        .catch(error => {
            console.error('Error fetching the Bitcoin price:', error);
            return null;
        });
}

// Function to create the Footer
function createFooter() {
    var footerBar = document.createElement('div');
    footerBar.className = 'footer';
    footerBar.innerHTML = `
        <div class="footer-content">
            <!-- Profile Image -->
            <img src="img/me.jpg" alt="Profile" class="footer-avatar">
            
            <!-- Name and Title -->
            <div class="footer-text">
                <h4>Manuel Schmutz</h4>
                <p>Electronics Technician and Musician</p>
                <p id="bitcoin-price"></p> <!-- Placeholder for Bitcoin price -->
            </div>
        </div>
        <!-- About Section -->
        <div class="footer-about">
            <h5>About</h5>
            <p>GM, I'm Manuel. I enjoy building dynamic, creative products from start to finish.</p>
        </div>
    `;

    // Append footer to the body
    document.body.append(footerBar);

    // Fetch and display Bitcoin price in the specified <p> tag
    fetchBitcoinPrice().then(price => {
        if (price) {
            document.getElementById('bitcoin-price').innerText = `Bitcoin Price: $${price} USD`;
        } else {
            document.getElementById('bitcoin-price').innerText = 'Error fetching Bitcoin price';
        }
    });
}

// Call the function to create and insert the footer when the DOM is loaded
document.addEventListener('DOMContentLoaded', createFooter);
